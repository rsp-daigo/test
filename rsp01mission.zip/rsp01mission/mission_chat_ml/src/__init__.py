# coding: utf-8
from main import main # NOQA
from main import PredictExecutor # NOQA
from main import PredictIntaractiveExecutor # NOQA
