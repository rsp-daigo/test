
# 切り出しメモ
## Earth Seen From Space Station ISS [Real Speed HD].mp4

```bash
ffmpeg -ss 192 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 100 ../001.mp4
ffmpeg -ss 400 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 80 ../002.mp4
ffmpeg -ss 705 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 90 ../003.mp4
ffmpeg -ss 833 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 80 ../004.mp4
ffmpeg -ss 1068 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 80 ../005.mp4
ffmpeg -ss 1388 -i Earth\ Seen\ From\ Space\ Station\ ISS\ \[Real\ Speed\ HD\].mp4 -t 60 ../006.mp4
```


## 国際宇宙ステーション（ISS）から撮影した夜の地球 【Full HD 1080p】.mp4

```bash
ffmpeg -ss 30 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 13 ../007.mp4
ffmpeg -ss 140 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 17 ../008.mp4
ffmpeg -ss 159 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 9 ../009.mp4
ffmpeg -ss 170 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 14 ../010.mp4
ffmpeg -ss 198 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 12 ../011.mp4
ffmpeg -ss 225 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 8 ../012.mp4
ffmpeg -ss 235 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 6 ../013.mp4
ffmpeg -ss 243 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 15 ../014.mp4
ffmpeg -ss 270 -i 国際宇宙ステーション（ISS）から撮影した夜の地球\ 【Full\ HD\ 1080p】.mp4 -t 15 ../015.mp4
```


## 【 ISS 】 国際宇宙ステーション 日本上空を飛行.mp4
全編を 016.mp4 として使う


## 宇宙から撮影された地球【Full HD 1080p】.mp4

```bash
ffmpeg -ss 165 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 23 ../017.mp4
ffmpeg -ss 730 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 51 ../018.mp4
ffmpeg -ss 730 -i fin/宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 19 ../018_1.mp4
ffmpeg -ss 750 -i fin/宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 30 ../018_2.mp4
ffmpeg -ss 796 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 20 ../019.mp4
ffmpeg -ss 864 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 15 ../020.mp4
ffmpeg -ss 881 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 20 ../021.mp4
ffmpeg -ss 911 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 15 ../022.mp4
ffmpeg -ss 928 -i 宇宙から撮影された地球【Full\ HD\ 1080p】.mp4 -t 16 ../023.mp4
```


## NASA - Earth view from ISS - 1080p60 HD - (time lapse).mp4

```bash
ffmpeg -ss 13 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 23 ../024.mp4
ffmpeg -ss 43 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 13 ../025.mp4
ffmpeg -ss 346 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 54 ../026.mp4
ffmpeg -ss 441 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 16 ../027.mp4
ffmpeg -ss 467 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 19 ../028.mp4
ffmpeg -ss 496 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 15 ../029.mp4
ffmpeg -ss 589 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 18 ../030.mp4
ffmpeg -ss 607 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 3 ../031.mp4
ffmpeg -ss 732 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 3 ../032.mp4
ffmpeg -ss 753 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 27 ../033.mp4
ffmpeg -ss 960 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 18 ../034.mp4
ffmpeg -ss 984 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 14 ../035.mp4
ffmpeg -ss 1130 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 27 ../036.mp4
ffmpeg -ss 1506 -i NASA\ -\ Earth\ view\ from\ ISS\ -\ 1080p60\ HD\ -\ \(time\ lapse\).mp4 -t 35 ../037.mp4
```
