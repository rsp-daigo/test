# -*- coding: utf-8 -*-
from mission_main.main.mission_system import MissionSystem

if __name__ == "__main__":
    mission = MissionSystem()
    mission.run()
